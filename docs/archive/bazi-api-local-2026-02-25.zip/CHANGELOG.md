# Changelog

All notable changes to this project will be documented in this file.

## [Unreleased]

## [v5.0.0] - 2024-07-12
### Added
- 新增 `/api/v1/bazi/full`，包含八字、十神、流年、大运（12 节气锚点、天数向上取整除以 3）、五行、强弱分级、用神。
- 固定方法默认值以保持可追踪性（例如 day_boundary_rule=zi_initial, solar_time_rule=longitude_only, dayun_method=sxtwl_next_jieqi_div3 等）。
- 警告位置明确：bazi_full 的 `warnings` 在顶层；verify 继续使用 `validation.warnings`。增加中国区经度提示，收紧 lon 范围为 [-180, 180]。
- 记录 `day_boundary_crossed` 语义：表示输入处于子初窗口（23:00+），不保证日柱实际变动；raw 仅作为调试追踪，未来仅追加字段。
- 新增文档样例（verify 与 bazi_full，包括 dayun 锚点 trace），更新 README 与 API 说明为 v5.0.0。

## [v5.3.1] - 2026-02-25

### Added
- 请求关联 (`request_id`): 当请求头包含 `X-Request-Id` 且有效时优先沿用，否则服务端生成 UUIDv4；同时在响应体 `request_id` 与响应头 `X-Request-Id` 返回。
- 保护策略 (Guardrails):
  - `X-Request-Id` 含非法字符 -> 替换为 UUID，并在 `validation.warnings` 中发出 `request_id_invalid_chars`。
  - `X-Request-Id` 长度超过 128 -> 截断，并在 `validation.warnings` 中发出 `request_id_truncated`。
- 非阻塞 `validation.warnings`: 采用 `code: key=value ...` 规范化格式，例如 `tz_mismatch: dt_offset=+09:00 tz=Asia/Shanghai action=tz_ignored_for_aware_dt`。

### Compatibility
- 不改变计算逻辑，现有客户端保持兼容。

### Gateway / Frontend
- 确保网关/反代不会剥离 `X-Request-Id` 响应头。
- 如需在浏览器前端读取 `X-Request-Id`，请通过 CORS 暴露：`Access-Control-Expose-Headers: X-Request-Id`。
