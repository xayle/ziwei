"""Interpretation layer (stub)."""
from __future__ import annotations

from boundary import Validation


def interpret(validation: Validation):
    """Generate human-readable output; must respect interpretation gating."""
    raise NotImplementedError
