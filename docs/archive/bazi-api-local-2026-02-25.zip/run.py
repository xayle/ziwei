"""FastAPI entrypoint."""
from __future__ import annotations

import importlib.metadata
import importlib.util
import re
from datetime import datetime, timedelta
from pathlib import Path
from uuid import uuid4
from zoneinfo import ZoneInfo

from fastapi import FastAPI, Header, HTTPException, Response
from fastapi.staticfiles import StaticFiles

from constants import API_VERSION, JIEQI_THRESHOLD_MIN, RULE_VERSION, SHICHEN_THRESHOLD_MIN, SUPPORTED_YEAR_RANGE
from schemas import (
    BackendInfo,
    PillarModel,
    PillarsModel,
    RiskFlagsModel,
    ValidationModel,
    VerifyRequest,
    VerifyResponse,
    WarningModel,
)
from verify import verify_full

from config import settings
from constants import MAX_LON, MIN_LON
from db import init_db
from routers import bazi as bazi_router
from routers import cases as cases_router
from routers import compute as compute_router
from routers import snapshots as snapshots_router
from services.normalize_input import validate_lon_strict, warn_lon_cn_range

app = FastAPI(title="BaZi v5.3", version=API_VERSION)

# --- static UI (local/intranet) ---
_static_dir = Path(__file__).resolve().parent / "static"
if _static_dir.exists():
	app.mount("/static", StaticFiles(directory=str(_static_dir)), name="static")

app.include_router(cases_router.router)
app.include_router(bazi_router.router)
app.include_router(compute_router.router)
app.include_router(snapshots_router.router)


@app.on_event("startup")
def _startup_init_db():
	init_db()


def _backend_status(name: str) -> tuple[bool, str]:
	spec = importlib.util.find_spec(name)
	available = spec is not None
	version = "unavailable"
	if available:
		try:
			version = importlib.metadata.version(name)
		except importlib.metadata.PackageNotFoundError:
			version = "unknown"
	return available, version


@app.get("/health")
def health():
	tz = ZoneInfo("Asia/Shanghai")
	now_local = datetime.now(tz)
	sxtwl_ok, sxtwl_ver = _backend_status("sxtwl")
	cnlunar_ok, cnlunar_ver = _backend_status("cnlunar")
	return {
		"status": "ok",
		"api_version": API_VERSION,
		"rule_version": RULE_VERSION,
		"sxtwl_available": sxtwl_ok,
		"sxtwl_version": sxtwl_ver,
		"cnlunar_available": cnlunar_ok,
		"cnlunar_version": cnlunar_ver,
		"tz": "Asia/Shanghai",
		"now_utc8": now_local.isoformat(),
		"supported_year_range": SUPPORTED_YEAR_RANGE,
		"thresholds": {
			"shichen_minutes": SHICHEN_THRESHOLD_MIN,
			"jieqi_minutes": JIEQI_THRESHOLD_MIN,
			"jieqi_set": "12jie",
		},
	}


def _attach_tz(dt: datetime, tz_name: str) -> datetime:
	tz = ZoneInfo(tz_name)
	if dt.tzinfo is None or dt.utcoffset() is None:
		return dt.replace(tzinfo=tz)
	return dt.astimezone(tz)


def _format_offset(td: timedelta) -> str:
	seconds = int(td.total_seconds())
	sign = "+" if seconds >= 0 else "-"
	seconds = abs(seconds)
	hours, remainder = divmod(seconds, 3600)
	minutes = remainder // 60
	return f"{sign}{hours:02d}:{minutes:02d}"


def _safe_offset(td: timedelta | None) -> str:
	if td is None:
		return ""
	return _format_offset(td)


_REQUEST_ID_PATTERN = re.compile(r"^[A-Za-z0-9._-]+$")


def _sanitize_request_id(candidate: str | None, warnings: list[str]) -> str:
	if candidate is None:
		return str(uuid4())
	rid = candidate.strip()
	if not rid:
		return str(uuid4())
	if not _REQUEST_ID_PATTERN.match(rid):
		warnings.append("request_id_invalid_chars: action=replaced_with_uuid")
		return str(uuid4())
	if len(rid) > 128:
		warnings.append("request_id_truncated: max_len=128")
		rid = rid[:128]
	return rid


def _to_pillars_model(pillars) -> PillarsModel:
	return PillarsModel(
		year=PillarModel(**pillars.year.__dict__),
		month=PillarModel(**pillars.month.__dict__),
		day=PillarModel(**pillars.day.__dict__),
		hour=PillarModel(**pillars.hour.__dict__),
	)


@app.post("/api/v1/verify", response_model=VerifyResponse)
def api_verify(
	body: VerifyRequest,
	response: Response,
	x_request_id: str | None = Header(None, alias="X-Request-Id"),
):
	warnings: list[object] = []
	req_id = _sanitize_request_id(x_request_id, warnings)
	response.headers["X-Request-Id"] = req_id
	if body.dt.tzinfo is not None and body.dt.utcoffset() is not None:
		target_tz = ZoneInfo(body.tz)
		target_offset = target_tz.utcoffset(body.dt)
		dt_offset = body.dt.utcoffset()
		if target_offset is not None and target_offset != dt_offset:
			offset_str = _safe_offset(dt_offset)
			warnings.append(
				f"tz_mismatch: dt_offset={offset_str} tz={body.tz} action=tz_ignored_for_aware_dt"
			)

	dt = _attach_tz(body.dt, body.tz)
	lon = validate_lon_strict(body.lon)

	# soft warning for CN range when tz=Asia/Shanghai
	warnings.extend(warn_lon_cn_range(body.tz, lon))

	try:
		result = verify_full(dt, lon=lon, use_solar=body.solar_time_enabled, mode=body.mode)
	except HTTPException:
		raise
	except Exception as exc:  # pragma: no cover - rely on existing verify tests
		raise HTTPException(status_code=500, detail=str(exc))

	rp = _to_pillars_model(result.pillars_primary)
	rs = _to_pillars_model(result.pillars_secondary) if result.pillars_secondary else None
	rf = RiskFlagsModel(**result.risk_flags.__dict__)
	v_payload = result.validation.__dict__.copy()
	v_payload["risk_flags"] = rf
	raw_warnings = list(result.validation.warnings) + warnings
	parsed_warnings = []
	for w in raw_warnings:
		if isinstance(w, dict):
			parsed_warnings.append(WarningModel.model_validate(w))
		else:
			parsed_warnings.append(WarningModel(code="legacy", message=str(w)))

	v_payload["warnings"] = parsed_warnings
	v = ValidationModel(**v_payload)

	sxtwl_ok, _ = _backend_status("sxtwl")
	cnlunar_ok, _ = _backend_status("cnlunar")

	backend_info = BackendInfo(
		primary=settings.primary_backend,
		secondary="cnlunar" if body.mode == "dual" else None,
		sxtwl_available=sxtwl_ok,
		cnlunar_available=cnlunar_ok,
	)

	return VerifyResponse(
		api_version=API_VERSION,
		rule_version=RULE_VERSION,
		request_id=req_id,
		backend=backend_info,
		mode_requested=result.mode_requested,  # type: ignore[arg-type]
		mode_effective=result.mode_effective,  # type: ignore[arg-type]
		pillars_primary=rp,
		pillars_secondary=rs,
		risk_flags=rf,
		validation=v,
		solar_time_offset_minutes=result.solar_time_offset_minutes,
		dt_input=body.dt.isoformat(),
		dt_effective_utc8=dt.isoformat(),
		tz=body.tz,
	)
