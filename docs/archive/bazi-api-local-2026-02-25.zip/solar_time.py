"""Solar time corrections (stub)."""
from __future__ import annotations

from typing import Tuple

from constants import DEFAULT_LON


def compute_solar_correction_minutes(lon: float) -> Tuple[float, float]:
    """Return (longitude_delta_deg, solar_correction_minutes).

    longitude_delta_deg: lon - 120 (east positive)
    solar_correction_minutes: correction to apply to civil time (minutes)
    """
    delta = lon - DEFAULT_LON
    correction_minutes = 4.0 * delta
    return delta, correction_minutes
