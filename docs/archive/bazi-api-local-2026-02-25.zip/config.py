"""Runtime configuration placeholders."""
from __future__ import annotations

from dataclasses import dataclass
from pathlib import Path
from typing import Optional

from constants import DEFAULT_LON, RULE_VERSION, API_VERSION


@dataclass
class Settings:
    primary_backend: str = "sxtwl"
    default_lon: float = DEFAULT_LON
    rule_version: str = RULE_VERSION
    api_version: str = API_VERSION
    solar_time_enabled: bool = False
    lat: Optional[float] = None  # optional, not used in calc
    db_path: Path = Path(__file__).resolve().parent / "data" / "mingli.db"


settings = Settings()
