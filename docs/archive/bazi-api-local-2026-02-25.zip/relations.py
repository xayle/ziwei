"""Ten gods / relationships (stub)."""
from __future__ import annotations
