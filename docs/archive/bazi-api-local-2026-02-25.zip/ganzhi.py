"""Ganzhi utilities (stub)."""
from __future__ import annotations


def build_pillar(stem: str, branch: str):
    raise NotImplementedError
