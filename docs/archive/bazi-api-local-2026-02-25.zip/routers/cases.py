from __future__ import annotations

from datetime import datetime, timezone
from typing import List, Optional, cast

from fastapi import APIRouter, Depends, HTTPException, Query, status
from sqlalchemy.sql.elements import ColumnElement
from sqlmodel import Session, select

from db import get_session
from models import Case, Snapshot
from schemas import CaseCreate, CaseOut, CasePatch

router = APIRouter(prefix="/api/v1/cases", tags=["cases"])


def _now_utc() -> datetime:
    return datetime.now(timezone.utc)


@router.post("", response_model=CaseOut, status_code=status.HTTP_201_CREATED)
def create_case(payload: CaseCreate, session: Session = Depends(get_session)):
    case = Case(**payload.model_dump())
    now = _now_utc()
    case.created_at = now
    case.updated_at = now
    session.add(case)
    session.commit()
    session.refresh(case)
    return CaseOut.model_validate(case)


@router.get("", response_model=List[CaseOut])
def list_cases(
    q: Optional[str] = Query(default=None, description="Search by name substring"),
    tag: Optional[str] = Query(default=None, description="Filter by tag substring"),
    limit: int = Query(default=20, ge=1, le=100),
    offset: int = Query(default=0, ge=0),
    order: str = Query(default="updated_at", pattern="^(updated_at|created_at|name)$"),
    dir: str = Query(default="desc", pattern="^(asc|desc)$"),
    session: Session = Depends(get_session),
):
    stmt = select(Case)
    name_col = cast(ColumnElement[str], Case.name)
    tags_col = cast(ColumnElement[str], Case.tags)
    if q:
        stmt = stmt.where(name_col.contains(q))
    if tag:
        stmt = stmt.where(tags_col.contains(tag))
    order_col = cast(ColumnElement, getattr(Case, order))
    if dir == "desc":
        order_col = order_col.desc()
    else:
        order_col = order_col.asc()
    stmt = stmt.order_by(order_col).offset(offset).limit(limit)
    cases = session.exec(stmt).all()
    results: List[CaseOut] = []
    for c in cases:
        latest_verify = (
            session.exec(
                select(Snapshot)
                .where(Snapshot.case_id == c.id, Snapshot.kind == "verify")
                .order_by(cast(ColumnElement[datetime], Snapshot.created_at).desc())
                .limit(1)
            ).first()
            or None
        )
        summary = None
        if latest_verify:
            summary = {
                "snapshot_id": latest_verify.id,
                "summary_level": latest_verify.summary_level,
                "summary_warning_count": latest_verify.summary_warning_count,
                "summary_diff_count": latest_verify.summary_diff_count,
            }
        co = CaseOut.model_validate(c)
        co.latest_verify_summary = summary
        results.append(co)
    return results


@router.get("/{case_id}", response_model=CaseOut)
def get_case(case_id: str, session: Session = Depends(get_session)):
    case = session.get(Case, case_id)
    if not case:
        raise HTTPException(status_code=status.HTTP_404_NOT_FOUND, detail="case_not_found")
    latest_verify = (
        session.exec(
            select(Snapshot)
            .where(Snapshot.case_id == case.id, Snapshot.kind == "verify")
            .order_by(cast(ColumnElement[datetime], Snapshot.created_at).desc())
            .limit(1)
        ).first()
        or None
    )
    summary = None
    if latest_verify:
        summary = {
            "snapshot_id": latest_verify.id,
            "summary_level": latest_verify.summary_level,
            "summary_warning_count": latest_verify.summary_warning_count,
            "summary_diff_count": latest_verify.summary_diff_count,
        }
    co = CaseOut.model_validate(case)
    co.latest_verify_summary = summary
    return co


@router.patch("/{case_id}", response_model=CaseOut)
def patch_case(case_id: str, payload: CasePatch, session: Session = Depends(get_session)):
    case = session.get(Case, case_id)
    if not case:
        raise HTTPException(status_code=status.HTTP_404_NOT_FOUND, detail="case_not_found")
    data = payload.model_dump(exclude_unset=True)
    for key, value in data.items():
        setattr(case, key, value)
    case.updated_at = _now_utc()
    session.add(case)
    session.commit()
    session.refresh(case)
    co = CaseOut.model_validate(case)
    return co
