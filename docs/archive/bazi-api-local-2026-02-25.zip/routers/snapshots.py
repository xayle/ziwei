from __future__ import annotations

from typing import List, Optional

from fastapi import APIRouter, Depends, HTTPException, Query, status
from sqlmodel import Session, select

from db import get_session
from models import Snapshot
from schemas import SnapshotOut

router = APIRouter(prefix="/api/v1", tags=["snapshots"])


@router.get("/cases/{case_id}/snapshots", response_model=List[SnapshotOut])
def list_snapshots(
    case_id: str,
    limit: int = Query(default=20, ge=1, le=100),
    offset: int = Query(default=0, ge=0),
    session: Session = Depends(get_session),
):
    stmt = select(Snapshot).where(Snapshot.case_id == case_id).order_by(Snapshot.created_at.desc())
    stmt = stmt.offset(offset).limit(limit)
    snaps = session.exec(stmt).all()
    return [SnapshotOut.model_validate(s) for s in snaps]


@router.get("/snapshots/{snapshot_id}", response_model=SnapshotOut)
def get_snapshot(snapshot_id: str, session: Session = Depends(get_session)):
    snap = session.get(Snapshot, snapshot_id)
    if not snap:
        raise HTTPException(status_code=status.HTTP_404_NOT_FOUND, detail="snapshot_not_found")
    return SnapshotOut.model_validate(snap)
