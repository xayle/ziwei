"""BaZi core orchestration (stub)."""
from __future__ import annotations

from boundary import Pillars


def build_bazi(dt_utc8, lon: float, use_solar: bool) -> Pillars:
    """Construct pillars using primary backend."""
    raise NotImplementedError
