# BaZi Service

## API
- Verify: [docs/api.md](docs/api.md#post-apiv1verify)
- BaZi Full: [docs/api.md](docs/api.md#post-apiv1bazifull)
- OpenAPI: [docs/openapi.json](docs/openapi.json)

## Release Notes
- Latest: [v5.0.0](CHANGELOG.md)
- All releases: [docs/release-notes/](docs/release-notes/)

## BaZi Full quickstart (v5.0.0)
- Warnings: top-level `warnings` (object list); verify keeps `validation.warnings`.
- Methods: fixed defaults for traceability (day_boundary_rule=zi_initial, solar_time_rule=longitude_only, dayun_method=sxtwl_next_jieqi_div3, ...). See [docs/api.md](docs/api.md#post-apiv1bazifull) for the full set.
- Raw: debug/trace only; may add fields in patch releases (no silent deletions/renames). `day_boundary_crossed` means input is in the zi_initial window (23:00+), not a guarantee that day pillar changes.
- Samples: see [docs/samples](docs/samples) for verify and bazi_full (including dayun anchor trace).

## Development
- Install deps: `pip install -r requirements.txt`
- Dev lint/type deps: `pip install -r requirements-dev.txt` (see [requirements-dev.txt](requirements-dev.txt))
- Run tests: `python -m pytest -q`
- Regression samples: `python run_cases.py`
- Lint: `ruff check .`
- Type check: `pyright`

## Local Smoke
- Start API (terminal A): `uvicorn run:app --reload --host 127.0.0.1 --port 8000`
- Run smoke (terminal B): `BASE_URL=http://127.0.0.1:8000 bash scripts/smoke_local.sh` or `BASE_URL=http://127.0.0.1:8000 pwsh scripts/smoke_local.ps1`
- What it covers: /health plus /api/v1/verify cases for request_id (generate/echo/invalid/truncate) and tz_mismatch warning. It runs all cases, summarizes failures, and exits non-zero on any failure.
- Dependencies: curl + python (PowerShell uses curl.exe). No extra tools required.

## Local UI
- Serve static: run app normally and open http://127.0.0.1:8000/static/verify.html
- Purpose: minimal in-browser client for POST /api/v1/verify using pillars_primary as the main display; dual mode shows secondary and diff_fields.
