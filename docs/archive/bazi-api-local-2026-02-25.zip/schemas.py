"""API schemas using Pydantic v2."""
from __future__ import annotations

import re
from datetime import datetime
from typing import Any, Dict, Literal, Optional
from zoneinfo import ZoneInfo

from pydantic import BaseModel, Field, field_validator, model_validator

from constants import MAX_LON, MIN_LON


class PillarModel(BaseModel):
    stem: str = Field(..., description="Heavenly stem")
    branch: str = Field(..., description="Earthly branch")
    ganzhi: Optional[str] = Field(None, description="Combined ganzhi, if available")


class PillarsModel(BaseModel):
    year: PillarModel
    month: PillarModel
    day: PillarModel
    hour: PillarModel


class RiskFlagsModel(BaseModel):
    near_shichen_boundary: bool = Field(..., description="True when within shichen boundary threshold")
    near_jieqi_boundary: bool = Field(..., description="True when within jieqi boundary threshold")
    jieqi_boundary_status: Literal["ok", "unavailable"] = Field(
        ..., description="ok=jieqi context present; unavailable=jieqi context missing so near/offset may be null"
    )
    minutes_to_shichen_boundary: Optional[float] = Field(None, description="Minutes to nearest shichen boundary")
    minutes_to_jieqi_boundary: Optional[float] = Field(None, description="Minutes to nearest jieqi boundary")


class ValidationModel(BaseModel):
    level: Literal["L0", "L1", "L2", "L3"] = Field(..., description="Validation level gate")
    mode: Literal["dual", "single"] = Field(..., description="Effective validation mode")
    recommended: Literal["beijing_time", "solar_time"] = Field(
        ..., description="Recommended interpretation basis; may expand in future"
    )
    interpretation_enabled: bool = Field(..., description="Whether interpretation is allowed")
    reasons: list[str] = Field(..., description="Reason codes contributing to validation result")
    diff_fields: list[Literal["year", "month", "day", "hour"]] = Field(
        ..., description="Which pillars differ between primary and secondary"
    )
    risk_flags: RiskFlagsModel
    warnings: list[WarningModel] = Field(default_factory=list, description="Non-blocking warnings for client display")


class BackendInfo(BaseModel):
    primary: str = Field(..., description="Primary backend requested")
    secondary: Optional[str] = Field(None, description="Secondary backend when mode=dual")
    sxtwl_available: bool = Field(..., description="sxtwl availability at request time")
    cnlunar_available: bool = Field(..., description="cnlunar availability at request time")


class WarningModel(BaseModel):
    code: str
    message: str
    meta: Optional[Dict[str, Any]] = None


class VerifyRequest(BaseModel):
    dt: datetime = Field(..., description="Input datetime; aware or naive ISO-8601")
    lon: float = Field(..., description="Longitude in degrees within supported range")
    mode: Literal["dual", "single"] = Field("dual", description="Requested mode")
    solar_time_enabled: bool = Field(False, description="Enable solar-time adjustment when true")
    tz: str = Field("Asia/Shanghai", description="Timezone used only when dt is naive")

    @model_validator(mode="after")
    def validate_lon(self):  # type: ignore[override]
        if not (MIN_LON <= self.lon <= MAX_LON):
            raise ValueError(f"lon must be between {MIN_LON} and {MAX_LON}")
        return self


class VerifyResponse(BaseModel):
    api_version: str = Field(..., description="API semantic version")
    rule_version: str = Field(..., description="Rule/data version")
    request_id: str = Field(..., description="Request correlation id")
    backend: BackendInfo
    mode_requested: Literal["dual", "single"] = Field(..., description="Echo of requested mode")
    mode_effective: Literal["dual", "single"] = Field(..., description="Actual mode after fallback")
    pillars_primary: PillarsModel
    pillars_secondary: Optional[PillarsModel] = Field(None, description="Secondary pillars when dual mode succeeds")
    risk_flags: RiskFlagsModel
    validation: ValidationModel
    solar_time_offset_minutes: float = Field(
        ..., description="Solar correction applied in minutes; 0.0 when solar_time_enabled is false"
    )
    dt_input: str = Field(..., description="Parsed input datetime re-serialized via isoformat()")
    dt_effective_utc8: str = Field(..., description="Datetime normalized to Asia/Shanghai")
    tz: str = Field(..., description="Echo of requested timezone; only used when dt is naive")


# ---- BaZi Full ----


class BaziMethodsModel(BaseModel):
    day_boundary_rule: str = "zi_initial"
    solar_time_rule: str = "longitude_only"
    calendar_calc: str = "sxtwl"
    pillar_month_rule: str = "jieqi"
    ten_god_basis: str = "stem_only"
    liunian_calc: str = "gregorian_year_ganzhi"
    liunian_range_default: str = "[-2,2]"
    dayun_method: str = "sxtwl_next_jieqi_div3"
    dayun_boundary: str = "half_open"
    dayun_jieqi_anchor: str = "next"
    dayun_rounding: str = "ceil"
    dayun_days_per_month: int = 3
    dayun_direction_rule: str = "gender+year_stem_yinyang"
    wuxing_method: str = "stem_branch_hidden_weighted_v1"
    wuxing_weights_version: str = "v1"
    strength_method: str = "season_root_help_score_v1"
    strength_tier_rule: str = "score_threshold_v1"
    yongshen_method: str = "wuxing_balance_from_strength_v1"
    yongshen_output_style: str = "elements_only"
    warnings_format: str = "object_v1"


class TenGodsModel(BaseModel):
    year: Optional[str] = None
    month: Optional[str] = None
    day: Optional[str] = None
    hour: Optional[str] = None


class StrengthFactorModel(BaseModel):
    name: str
    score: float
    reason: Optional[str] = None


class DayMasterStrengthModel(BaseModel):
    score: float = 0.0
    tier: str = "pending"
    factors: list[StrengthFactorModel] = Field(default_factory=list)


class WuXingScoreModel(BaseModel):
    wood: float = 0.0
    fire: float = 0.0
    earth: float = 0.0
    metal: float = 0.0
    water: float = 0.0


class WuXingBreakdownModel(BaseModel):
    stem_contrib: dict[str, float] = Field(default_factory=dict)
    branch_contrib: dict[str, float] = Field(default_factory=dict)
    hidden_contrib: dict[str, float] = Field(default_factory=dict)
    weights: dict[str, float] = Field(default_factory=dict)


class YongShenModel(BaseModel):
    favor: list[str] = Field(default_factory=list)
    avoid: list[str] = Field(default_factory=list)
    rationale: Optional[str] = None


class DaYunItemModel(BaseModel):
    start_age: Optional[float] = None
    start_year: Optional[int] = None
    start_age_months: Optional[int] = None
    stem: Optional[str] = None
    branch: Optional[str] = None
    ten_god: Optional[str] = None
    flow_wuxing: Optional[str] = None


class DaYunModel(BaseModel):
    method: str = "pending"
    boundary: str = "pending"
    items: list[DaYunItemModel] = Field(default_factory=list)


class LiuNianItemModel(BaseModel):
    year: Optional[int] = None
    stem: Optional[str] = None
    branch: Optional[str] = None
    ten_god: Optional[str] = None
    clash: Optional[str] = None


class LiuNianResultModel(BaseModel):
    years_used: list[int] = Field(default_factory=list)
    items: list[LiuNianItemModel] = Field(default_factory=list)


class BaziRawDayunModel(BaseModel):
    birth_to_jieqi_days: Optional[float] = None
    computed_months_before_rounding: Optional[float] = None
    rounding_applied: Optional[str] = None
    anchor_jieqi_name: Optional[str] = None
    anchor_jieqi_dt: Optional[str] = None
    direction: Optional[str] = None
    direction_basis: dict[str, Any] = Field(
        default_factory=lambda: {"gender": None, "year_stem": None, "year_stem_yinyang": None}
    )
    status: str = "placeholder"
    sequence_start: str = "from_month_pillar"


class BaziRawModel(BaseModel):
    tz_used: str
    dt_effective_local: str
    dt_effective_utc: str
    dt_effective_local_offset_minutes: int
    solar_time_offset_minutes: int
    day_boundary_rule_used: str = "zi_initial"
    day_boundary_crossed: bool = False
    jieqi_context: dict[str, Any] = Field(default_factory=dict)
    dayun: BaziRawDayunModel = Field(default_factory=BaziRawDayunModel)


class BaziFullRequest(BaseModel):
    dt: datetime = Field(..., description="Input datetime; aware or naive ISO-8601")
    lon: float = Field(..., description="Longitude in degrees within supported range")
    mode: Literal["dual", "single"] = Field("dual", description="Requested mode")
    solar_time_enabled: bool = Field(False, description="Enable solar-time adjustment when true")
    tz: str = Field("Asia/Shanghai", description="Timezone used only when dt is naive")
    liunian_years: Optional[list[int]] = Field(None, description="Optional liunian year span [-N, N]")

    @model_validator(mode="after")
    def validate_lon(self):  # type: ignore[override]
        if not (MIN_LON <= self.lon <= MAX_LON):
            raise ValueError(f"lon must be between {MIN_LON} and {MAX_LON}")
        return self


class BaziFullResponse(BaseModel):
    api_version: str
    rule_version: str
    schema_version: str = "bazi_full@5.0"
    request_id: str
    warnings: list[WarningModel] = Field(default_factory=list)
    methods: BaziMethodsModel
    pillars_primary: PillarsModel
    pillars_secondary: Optional[PillarsModel] = None
    ten_gods: TenGodsModel = Field(default_factory=TenGodsModel)
    day_master_strength: DayMasterStrengthModel = Field(default_factory=DayMasterStrengthModel)
    wuxing_score: WuXingScoreModel = Field(default_factory=WuXingScoreModel)
    wuxing_breakdown: WuXingBreakdownModel = Field(default_factory=WuXingBreakdownModel)
    yongshen: YongShenModel = Field(default_factory=YongShenModel)
    dayun: DaYunModel = Field(default_factory=DaYunModel)
    liunian: LiuNianResultModel = Field(default_factory=LiuNianResultModel)
    raw: BaziRawModel


# ---- Cases / Snapshots ----

_TAG_PATTERN = re.compile(r"^[\w\s,\-\u4e00-\u9fff]+$")


class CaseBase(BaseModel):
    name: str
    gender: Optional[str] = None
    birth_dt_local: str
    tz: str
    birth_dt: Optional[str] = None
    city: Optional[str] = None
    lon: float
    solar_time_enabled: bool = False
    notes: Optional[str] = None
    tags: Optional[str] = None

    @field_validator("birth_dt_local")
    @classmethod
    def validate_birth_dt_local(cls, v: str) -> str:
        try:
            dt = datetime.fromisoformat(v)
        except ValueError:
            raise ValueError("birth_dt_local must be ISO8601 without offset")
        if dt.tzinfo is not None and dt.utcoffset() is not None:
            raise ValueError("birth_dt_local must not include offset")
        return v

    @field_validator("tz")
    @classmethod
    def validate_tz(cls, v: str) -> str:
        try:
            ZoneInfo(v)
        except Exception as exc:  # pragma: no cover - zoneinfo validation
            raise ValueError(f"tz must be IANA name: {exc}")
        return v

    @field_validator("tags")
    @classmethod
    def validate_tags(cls, v: Optional[str]) -> Optional[str]:
        if v is None:
            return v
        v = v.strip()
        if not v:
            return None
        if len(v) > 200:
            raise ValueError("tags too long (max 200)")
        if not _TAG_PATTERN.match(v):
            raise ValueError("tags may contain letters, digits, spaces, comma, hyphen, underscore, CJK")
        return v

    @model_validator(mode="after")
    def validate_lon(self):  # type: ignore[override]
        if not (MIN_LON <= self.lon <= MAX_LON):
            raise ValueError(f"lon must be between {MIN_LON} and {MAX_LON}")
        return self


class CaseCreate(CaseBase):
    pass


class CasePatch(BaseModel):
    name: Optional[str] = None
    gender: Optional[str] = None
    birth_dt_local: Optional[str] = None
    tz: Optional[str] = None
    birth_dt: Optional[str] = None
    city: Optional[str] = None
    lon: Optional[float] = None
    solar_time_enabled: Optional[bool] = None
    notes: Optional[str] = None
    tags: Optional[str] = None

    @field_validator("birth_dt_local")
    @classmethod
    def validate_birth_dt_local(cls, v: Optional[str]) -> Optional[str]:
        if v is None:
            return v
        try:
            dt = datetime.fromisoformat(v)
        except ValueError:
            raise ValueError("birth_dt_local must be ISO8601 without offset")
        if dt.tzinfo is not None and dt.utcoffset() is not None:
            raise ValueError("birth_dt_local must not include offset")
        return v

    @field_validator("tz")
    @classmethod
    def validate_tz(cls, v: Optional[str]) -> Optional[str]:
        if v is None:
            return v
        try:
            ZoneInfo(v)
        except Exception as exc:
            raise ValueError(f"tz must be IANA name: {exc}")
        return v

    @field_validator("tags")
    @classmethod
    def validate_tags(cls, v: Optional[str]) -> Optional[str]:
        if v is None:
            return v
        v = v.strip()
        if not v:
            return None
        if len(v) > 200:
            raise ValueError("tags too long (max 200)")
        if not _TAG_PATTERN.match(v):
            raise ValueError("tags may contain letters, digits, spaces, comma, hyphen, underscore, CJK")
        return v

    @model_validator(mode="after")
    def validate_lon(self):  # type: ignore[override]
        lon = getattr(self, "lon", None)
        if lon is None:
            return self
        if not (MIN_LON <= lon <= MAX_LON):
            raise ValueError(f"lon must be between {MIN_LON} and {MAX_LON}")
        return self


class CaseOut(CaseBase):
    id: str
    created_at: datetime
    updated_at: datetime
    last_snapshot_at: Optional[datetime] = None
    api_version_last: Optional[str] = None
    rule_version_last: Optional[str] = None
    schema_version: Optional[str] = None
    latest_verify_summary: Optional[dict] = None


class SnapshotOut(BaseModel):
    id: str
    case_id: str
    kind: str
    compute_flags: Optional[dict] = None
    input_json: Optional[dict] = None
    output_json: Optional[dict] = None
    backend_json: Optional[dict] = None
    api_version: Optional[str] = None
    rule_version: Optional[str] = None
    schema_version: Optional[str] = None
    summary_level: Optional[str] = None
    summary_warning_count: Optional[int] = None
    summary_diff_count: Optional[int] = None
    summary_engine_primary: Optional[str] = None
    note: Optional[str] = None
    created_at: datetime


# ---- Compute ----


class ComputeRequest(BaseModel):
    compute_bazi: bool = True
    do_verify: bool = True
    mode: Literal["dual", "single"] = "dual"
    solar_time_enabled: Optional[bool] = False
    liunian_years: Optional[list[int]] = None


class ComputeTaskStatus(BaseModel):
    status: Literal["success", "failed", "skipped"]
    snapshot_id: Optional[str]
    message: Optional[str] = None


class ComputeResponse(BaseModel):
    compute_batch_id: str
    case_id: str
    input_effective: Dict[str, Any]
    tasks: Dict[str, ComputeTaskStatus]
    snapshots_created: list[SnapshotOut]
