# Core constants for v5.3
API_VERSION = "v1"
RULE_VERSION = "v5.3"
DEFAULT_LON = 120.0
SUPPORTED_YEAR_RANGE = (1900, 2101)
SHICHEN_THRESHOLD_MIN = 15
JIEQI_THRESHOLD_MIN = 60
# Global lon bounds
MIN_LON, MAX_LON = -180.0, 180.0
# China reference bounds (for warnings only)
CN_MIN_LON, CN_MAX_LON = 73.0, 135.0
MIN_LAT, MAX_LAT = 3.0, 54.0
